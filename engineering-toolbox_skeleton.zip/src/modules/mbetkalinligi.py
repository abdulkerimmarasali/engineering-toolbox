from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel

class MbEtKalinligiModule(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Gövde Et Kalınlığı (placeholder)"))
