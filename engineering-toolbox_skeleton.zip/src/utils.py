from dataclasses import dataclass, field
from typing import Dict, List, Optional

@dataclass
class CalcResult:
    values: Dict[str, float] = field(default_factory=dict)
    checks: Dict[str, bool] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    info: Optional[str] = None

def to_float(s: str) -> float:
    return float(str(s).strip().replace(",", "."))
