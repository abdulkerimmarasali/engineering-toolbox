# engineering-toolbox

PyQt-based engineering calculation toolbox (pressure vessels, fasteners/threads, O-ring sealing, retaining rings).

## Run
```bash
pip install -r requirements.txt
python -m src.main
```

## Data
Place `sstm_veritabani.db` under `data/` (ignored by default).
