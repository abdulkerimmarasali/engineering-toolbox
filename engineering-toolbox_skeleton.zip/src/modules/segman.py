from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel

class SegmanModule(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Segman Dayanım (placeholder)"))
