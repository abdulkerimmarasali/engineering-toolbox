from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel

class AlinContaCivataModule(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Alın Conta Civata Yerleşimi (placeholder)"))
