from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel

class MetrikDisModule(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Metrik Diş (placeholder)"))
