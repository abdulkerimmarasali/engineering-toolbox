import os
import sqlite3
from typing import Any, Iterable, List, Tuple, Optional

DB_PATH_DEFAULT = os.path.join(os.path.dirname(os.path.dirname(__file__)), "..", "data", "sstm_veritabani.db")

def connect(db_path: Optional[str] = None) -> sqlite3.Connection:
    path = db_path or os.path.abspath(DB_PATH_DEFAULT)
    return sqlite3.connect(path)

def fetch_all(query: str, params: Tuple[Any, ...] = (), db_path: Optional[str] = None) -> List[Tuple[Any, ...]]:
    with connect(db_path) as con:
        cur = con.cursor()
        cur.execute(query, params)
        return cur.fetchall()

def fetch_one(query: str, params: Tuple[Any, ...] = (), db_path: Optional[str] = None) -> Optional[Tuple[Any, ...]]:
    with connect(db_path) as con:
        cur = con.cursor()
        cur.execute(query, params)
        return cur.fetchone()
