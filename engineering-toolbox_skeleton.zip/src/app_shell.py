import importlib
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QListWidget, QVBoxLayout, QHBoxLayout, QLabel, QListWidgetItem
)
from PyQt5.QtCore import Qt
from .routes import CATEGORIES

class AppShell(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Engineering Toolbox")
        self.setMinimumSize(1100, 700)

        root = QWidget()
        self.setCentralWidget(root)

        layout = QHBoxLayout(root)

        # Left panel: categories + module list
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(8, 8, 8, 8)

        self.category_list = QListWidget()
        self.module_list = QListWidget()
        left_layout.addWidget(QLabel("Kategoriler"))
        left_layout.addWidget(self.category_list, 2)
        left_layout.addWidget(QLabel("Modüller"))
        left_layout.addWidget(self.module_list, 3)

        # Main panel
        self.content = QWidget()
        self.content_layout = QVBoxLayout(self.content)
        self.content_layout.setContentsMargins(12, 12, 12, 12)
        self.content_layout.addWidget(QLabel("Bir modül seçin."), alignment=Qt.AlignTop)

        layout.addWidget(left, 1)
        layout.addWidget(self.content, 3)

        # Populate categories
        for cat in CATEGORIES.keys():
            self.category_list.addItem(cat)

        self.category_list.currentTextChanged.connect(self._on_category_changed)
        self.module_list.itemClicked.connect(self._on_module_clicked)

        if self.category_list.count():
            self.category_list.setCurrentRow(0)

    def _on_category_changed(self, cat: str):
        self.module_list.clear()
        for title, mod_path, cls_name in CATEGORIES.get(cat, []):
            item = QListWidgetItem(title)
            item.setData(Qt.UserRole, (mod_path, cls_name))
            self.module_list.addItem(item)

    def _on_module_clicked(self, item: QListWidgetItem):
        mod_path, cls_name = item.data(Qt.UserRole)
        module = importlib.import_module(mod_path)
        cls = getattr(module, cls_name)
        widget = cls()

        # Clear current content
        while self.content_layout.count():
            w = self.content_layout.takeAt(0).widget()
            if w is not None:
                w.setParent(None)

        self.content_layout.addWidget(widget)
